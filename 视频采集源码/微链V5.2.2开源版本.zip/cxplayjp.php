<?php include('system/inc.php');
include('system/cxjp.php');
error_reporting(0);
header('Content-Type:text/html;charset=UTF-8');
$id=$_GET['id'];
$url = $cxurl."?vodids=".$id;
$data=json_decode(file_get_contents($url),true);
include('moban/'.$mkcms_bdyun.'/cxplayjp.php');?>
