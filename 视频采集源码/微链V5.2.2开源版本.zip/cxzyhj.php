<?php include('system/inc.php');
include('system/cxzyhj.php');
error_reporting(0);

header('Content-Type:text/html;charset=UTF-8');
if(empty($_GET['page'])){
    $_GET['page']='1';
}
$x=$_GET['page'];
$url = $cxurl."&p=".$x;
$data=json_decode(file_get_contents($url),true);
$recordcount = $data['page']['recordcount'];
$pagesize = $data['page']['pagesize'];
include('moban/'.$mkcms_bdyun.'/cxzyzz.php');?>
