<?php  include 'head.php';?>
<title>尝鲜视频列表-<?php echo $mkcms_seoname;?></title>
<meta name="keywords" content="视频排行,<?php echo $mkcms_keywords;?>">
<meta name="description" content="<?php echo $mkcms_description;?>">
</head>
<body >
<?php include 'header.php'; ?>
<div class="container">
<div class="row">
<!-- 幻灯片 -->
<?php echo get_ad(9)?>
<div class="stui-pannel stui-pannel-bg clearfix">
<div class="stui-pannel-box">



<div class="stui-pannel_hd">
<div class="stui-pannel__head active bottom-line clearfix">
<span class="more text-muted pull-right hidden-xs">千万部VIP视频免费等你观看</span>

</div>
</div>

<div class="stui-pannel_bd">
<ul class="stui-vodlist clearfix">
<?php
		for($i=0; $i<$pagesize; $i++){
			if (mb_strpos($data['data'][$i]['list_name'], '伦理片') === false) {
            if (mb_strpos($data['data'][$i]['list_name'], '福利') === false) {
	?>
<li class='col-md-6 col-sm-4 col-xs-3'>
<div class='stui-vodlist__box'>
<a class='stui-vodlist__thumb lazyload' href="cxplay.php?id=<?php echo $data['data'][$i]['vod_id'];?>" title='<?php
							echo $data['data'][$i]['vod_name'];
						?>' data-original='<?php echo $data['data'][$i]['vod_pic'];?>' >
<span class='play hidden-xs'></span>
                            
<span class='pic-text text-right'></span></a>
<div class='stui-vodlist__detail'>
<h4 class='title text-overflow'><a href='".$ccb."' title='<?php
							echo $data['data'][$i]['vod_name'];
						?>'><?php
							echo $data['data'][$i]['vod_name'];
						?></a></h4>
<p class='text text-overflow text-muted hidden-xs'><?php
							echo $data['data'][$i]['vod_actor'];
						?></p>
</div>
</div>
</li>
<?php
            }}}
		?> 
</ul>
</div>
</div>
</div>
</div>
<ul class="stui-page text-center cleafix">
<?php
if($_GET['page'] != 1){
     echo '<li ><a href="?page=1">首页</a></li>';
     echo '<li ><a href="?page=' . ($_GET['page']-1) . '">上一页</a></li>';
     } else {
echo '<li class="disabled"><a href="?page=1">首页</a></li>';
}
if($_GET['page'] == 1){
	echo '';
}else
echo '<li class="disabled"><a>'.($_GET['page']-1).'</a></li>';
echo '<li class="disabled color"><a>'.$_GET['page'].'</a></li>';
if($_GET['page'] == 20){
	echo '';
}else
echo '<li class="disabled"><a>'.($_GET['page']+1).'</a></li>';
if($_GET['page'] < 20){
     echo '<li ><a href="?page=' . ($_GET['page']+1) . '">下一页</a></li>';
     echo '<li ><a href="?page=20">尾页</a></li>';
     } else {
echo '<li class="disabled"><a>尾页</a></li>';
}	 

?>
</ul>
</div>

<div class="row"  style="margin-top:0px"><?php echo get_ad(8)?></div></div>
<?php  include 'footer.php';?>
