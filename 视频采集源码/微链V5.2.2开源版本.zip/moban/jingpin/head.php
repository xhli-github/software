<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<meta name='referrer' content="never">
<meta http-equiv="X-UA-Compatible" content="IE=EmulateIE10">
<meta name="renderer" content="webkit|ie-comp|ie-stand">
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0">
<link rel="stylesheet" href="<?php echo $mkcms_domain;?>moban/<?php echo $mkcms_bdyun;?>/css/style.css?v=1.0" type="text/css">
<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
<script type="text/javascript" src="<?php echo $mkcms_domain;?>moban/<?php echo $mkcms_bdyun;?>/js/stui_default.js?v1.0"></script>
<meta name="applicable-device" content="pc,mobile">
<script src="https://cdnjs.cloudflare.com/ajax/libs/flickity/2.0.10/flickity.pkgd.min.js"></script>
<link href="<?php echo $mkcms_domain;?>moban/<?php echo $mkcms_bdyun;?>/css/stui_default.css?v=1.0" rel="styleSheet" type="text/css">
<link href="<?php echo $mkcms_domain;?>moban/<?php echo $mkcms_bdyun;?>/css/stui_custom.css?v=1.0" rel="styleSheet" type="text/css">
<link href="<?php echo $mkcms_domain;?>moban/<?php echo $mkcms_bdyun;?>/css/stui_block.css?v=1.0" rel="styleSheet" type="text/css">