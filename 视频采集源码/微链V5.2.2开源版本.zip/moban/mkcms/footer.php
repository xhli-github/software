<div class="hy-gototop hidden-sm hidden-xs">
   <ul class="item clearfix">
    <li><a href="<?php echo $mkcms_domain;?>ucenter" title="会员中心"><i class="icon iconfont icon-tubiaozhizuomobanyihuifu-"></i></a></li>
    <li><a href="<?php echo $mkcms_domain;?>book.php" title="留言求片"><i class="icon iconfont icon-qiu"></i></a></li>
	<li><a href="javascript:()" title="观看记录"><i class="icon iconfont icon-icon-"></i></a><div class="history clearfix" style="width:200px">
				<div class="head">
					<h5 class="margin-0 text-muted">观看历史</h5>
				</div>
<?php if ($timu!=""){?>
<script type="text/javascript ">
					$MH.limit = 10;
					$MH.WriteHistoryBox(200, 170, 'font');
					$MH.recordHistory({
						name: '<?php echo $timu; ?>',
						link: '<?php echo 'http://'.$_SERVER['HTTP_HOST'].$_SERVER['PHP_SELF'].'?'.$_SERVER['QUERY_STRING'];?>',
						pic: ''
					})
				</script>
<?php }elseif ($d_name!=""){?>
<script type="text/javascript ">
					$MH.limit = 10;
					$MH.WriteHistoryBox(200, 170, 'font');
					$MH.recordHistory({
						name: '<?php echo $d_name; ?>',
						link: '<?php echo 'http://'.$_SERVER['HTTP_HOST'].$_SERVER['PHP_SELF'].'?'.$_SERVER['QUERY_STRING'];?>',
						pic: ''
					})
				</script>
<?php }else {?>
<script type="text/javascript ">
					$MH.limit = 10;
					$MH.WriteHistoryBox(200, 170, 'font');
					$MH.recordHistory({
						name: '',
						link: '',
						pic: ''
					})
				</script>
<?php }?>

			</div>	</li>		
    <li class="codehover"><a href="javascript:()" title="二维码"><i class="icon iconfont icon-erweima"></i></a>
     <div class="code clearfix">
      <p class="margin-0">
	  <img class="pic-responsive" src="<?php echo $mkcms_weixin;?>" alt="扫描二维码">
	  </p>
     </div></li>
    <li><a data-toggle="tooltip" data-placement="top" class="" href="javascript:scroll(0,0)" title="返回顶部"><i class="icon iconfont icon-top02"></i></a></li>   </ul>
  </div>
<div class="tabbar visible-xs">
		<a href="<?php echo $mkcms_domain;?>" class="item ">
        <i class="icon iconfont icon-shouye"></i>
        <p class="text">首页</p>
    </a>
	<a href="<?php echo $mkcms_domain;?>movie.php" class="item ">
        <i class="icon iconfont icon-caidanicondianyinghui"></i>
        <p class="text">电影</p>
    </a><a href="<?php echo $mkcms_domain;?>tv.php" class="item ">
        <i class="icon iconfont icon-tv_icon"></i>
        <p class="text">剧集</p>
    </a><a href="<?php echo $mkcms_domain;?>dongman.php" class="item ">
        <i class="icon iconfont icon-liebiaodaohang_dongman"></i>
        <p class="text">动漫</p>
    </a><a href="<?php echo $mkcms_domain;?>zongyi.php" class="item ">
        <i class="icon iconfont icon-jiemu"></i>
        <p class="text">综艺</p>
    </a>    </div>
<div class="container">
	<div class="row">
		<div class="hy-footer clearfix">
        <p style="padding: 0 4px;text-align:center" class="container-fluid"><span style="color:#000;text-align:center;"><?php echo $mkcms_copyright;?></span><?php echo $mkcms_tongji;?></p>
		</div>
	</div>
</div>
<div style="display:none;">
<?php echo $mkcms_tongji;?>
</div>
<script type="text/javascript" charset="utf-8">
    $(function() {
        $(".videopic.lazy").lazyload({effect: "fadeIn"});  
        $("[data-toggle='tooltip']").tooltip();
    });

</script>	
</body>
</html>