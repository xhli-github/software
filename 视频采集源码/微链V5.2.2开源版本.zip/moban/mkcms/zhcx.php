<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="renderer" content="webkit|ie-comp|ie-stand">
<meta http-equiv="X-UA-Compatible" content="IE=edge" />
<meta content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0;" name="viewport" />
<meta http-equiv="Cache-Control" content="no-cache, no-store, must-revalidate" />
<meta http-equiv="Pragma" content="no-cache" />
<meta http-equiv="Expires" content="0" />
<link rel="shortcut icon" href="favicon.ico" type="image/x-icon" />
<!--[if lt IE 9]>
<style type="text/css">

body{
background-repeat:repeat;background-size:inherit;background-attachment:fixed;background-position:center center;background: url(/style/acgurl.php); 
}
@media (max-width: 767px){
    body:before{background: url() center 0 no-repeat; background-attachment: fixed;background-size: cover;} 
}
</style>
<?php  include 'head.php';?>
<title><?php echo $mkcms_seoname;?> 最新热映影片资源在线观看</title>
<script>
(function(){
    var bp = document.createElement('script');
    var curProtocol = window.location.protocol.split(':')[0];
    if (curProtocol === 'https') {
        bp.src = 'https://zz.bdstatic.com/linksubmit/push.js';        
    }
    else {
        bp.src = 'http://push.zhanzhang.baidu.com/push.js';
    }
    var s = document.getElementsByTagName("script")[0];
    s.parentNode.insertBefore(bp, s);
})();
</script>
<meta name="keywords" content="<?php echo $mkcms_keywords ;?>，PHP源码采集开发请联系QQ号:2248186422">
<meta name="description" content="<?php echo $mkcms_description;?>">
</head>
<body ><?php  include 'header.php';
?>

<div class="container">
<div class="row"  style="margin-top:10px"></div>
	<div class="row">
    <div class="hy-layout clearfix">
        <div class="hy-min-screen clearfix">
            <div class="item clearfix">
              <dl class="clearfix" style="width:100%">
              <dt class="text-muted">资源站</dt>
              <dd class="clearfix">
               <a href='./cx.php' target='_self'>酷播片源</a>
														<a href='./cx131.php' target='_self'>OK片源</a>
														<a href='./cxok.php' target='_self'>135片源</a>
														<a href='./cxdd.php' target='_self'>精品片源</a>							
														<a href='./cxbo.php' target='_self'>永久片源</a>
														<a href='./cxyong.php' target='_self'>156片源</a>
														<a href='./cx135.php' target='_self'>C值片源</a>
														<a href='./cxkb.php' target='_self'>131片源</a>	
														<a href='./cxjp.php' target='_self'>最大片源</a>	
														<a href='./cxzk.php' target='_self'>极速片源</a>	
														<a href='./cxgq.php' target='_self'>最快片源</a>	
                                                        <a href='./cxlist.php' target='_self'>速播片源</a>	  
				</dd>
		    </div>
        </div>
        <div class="hy-min-screen clearfix">
            <div class="item clearfix">
              <dl class="clearfix" style="width:100%">
              <dt class="text-muted">影片类</dt>
              <dd class="clearfix">
               <a href='./cxzykh.php' target='_self'>科幻片</a>
														<a href='./cxzydz.php' target='_self'>动作片</a>
														<a href='./cxzyjq.php' target='_self'>剧情片</a>
														<a href='./cxzyxj.php' target='_self'>喜剧片</a>							
														<a href='./cxzyaq.php' target='_self'>爱情片</a>
														<a href='./cxzyzz.php' target='_self'>战争片</a>
														<a href='./cxzykb.php' target='_self'>恐怖片</a>
			  
				</dd>
		    </div>
        </div>
        <div class="hy-min-screen clearfix">
            <div class="item clearfix">
              <dl class="clearfix" style="width:100%">	  
              <dt class="text-muted">电视剧类</dt>
              <dd class="clearfix">
                <a href='cxzygc.php' target='_self'>国产剧</a><a href='cxzygj.php' target='_self'>港剧</a><a href='cxzyhj.php' target='_self'>韩剧</a><a href='cxzym.php' target='_self'>欧美剧</a><a href='cxzyr.php' target='_self'>日剧</a><a href='cxzyt.php' target='_self'>台剧</a><a href='./cxzytg.php' target='_self'>泰剧</a><a href='./cxzyy.php' target='_self'>越南剧</a>                           </dd>
              </dl>
            </div>
        </div>
		<div class="hy-min-screen clearfix">
            <div class="item clearfix">
              <dl class="clearfix" style="width:100%">	  
              <dt class="text-muted">资源类</dt>
              <dd class="clearfix">
                <a href='cxzyzy.php' target='_self'>综艺频道</a><a href='cxzydm.php' target='_self'>动漫频道</a><a href='cxzyj.php' target='_self'>记录片</a><a href='cxzyl.php' target='_self'>伦理片</a><a href='cxzys.php' target='_self'>写真视讯</a><a href='cxzyx.php' target='_self'>腿模写真</a><a href='./cxzyn.php' target='_self'>美女写真</a></dd>
              </dl>
            </div>
        </div>
		<div class="hy-min-screen clearfix">
            <div class="item clearfix">
              <dl class="clearfix" style="width:100%">	  
              <dt class="text-muted">其他</dt>
              <dd class="clearfix">
                <a href='zongyi.php' target='_self'>综艺</a><a href='dongman.php' target='_self'>动漫</a><a href='movie.php' target='_self'>电影</a><a href='tv.php' target='_self'>电视剧</a><a href='vlist.php?cid=0' target='_self'>热映</a><a href='gaoxiao.php' target='_self'>搞笑</a><a href='./yy.php' target='_self'>舞曲</a><a href='./zhibo.php' target='_self'>直播</a>                           </dd>
              </dl>
            </div>
        </div>
</div>


		<div class="hy-layout clearfix" style="margin-top: 0;">
			<div class="hy-switch-tabs active clearfix">
				<span class="text-muted pull-right hidden-xs">点击选择资源站查看更多最新影片！</span>
				<ul class="nav nav-tabs">
					<li class="active"><a href="cxzk.php">极速资源列表</a></li>
				</ul>
			</div>
			<div class="hy-video-list">
				<div class="item">
					<ul class="clearfix">
 							<?php
include('system/cxzk.php');
error_reporting(0);

$url = $cxurl."?p=".$x;
$data=json_decode(file_get_contents($url),true);
$recordcount = $data['page']['recordcount'];
$pagesize = $data['page']['pagesize'];
		for($i=0; $i<12; $i++){
			if (mb_strpos($data['data'][$i]['list_name'], '无') === false) {
            if (mb_strpos($data['data'][$i]['list_name'], '测') === false) {

			echo '<div class="col-md-2 col-sm-3 col-xs-4">
							<a class="videopic lazy" href="cxplayzk.php?id='.$data['data'][$i]['vod_id'].'" title="'.$data['data'][$i]['vod_name'].'" data-original="'.$data['data'][$i]['vod_pic'].'" style="background: url(./style/load.gif) no-repeat; background-position:50% 50%; background-size: cover;"><span class="play hidden-xs"></span><span class="score">'.$data['data'][$i]['vod_continu'].'</span></a>
							<div class="title">
								<h5 class="text-overflow"><a href="cxplayzk.php?id='.$data['data'][$i]['vod_id'].'" >'.$data['data'][$i]['vod_name'].'</a></h5>
							</div>
							<div class="subtitle text-muted text-muted text-overflow hidden-xs">'.$data['data'][$i]['vod_actor'].'</div>
						</div>';

		  }}} ?>

	</ul>
			</div></div>
		<div class="hy-layout clearfix" style="margin-top: 0;">
<ul class="nav nav-tabs">
					<li class="active"><a href="cx131.php">OK资源列表</a></li>
				</ul>
			</div>
			<div class="hy-video-list">
				<div class="item">
					<ul class="clearfix">
<?php
include('system/cx131.php');
error_reporting(0);

$url = $cxurl."?p=".$x;
$data=json_decode(file_get_contents($url),true);
$recordcount = $data['page']['recordcount'];
$pagesize = $data['page']['pagesize'];
		for($i=0; $i<12; $i++){
			if (mb_strpos($data['data'][$i]['list_name'], '无') === false) {
            if (mb_strpos($data['data'][$i]['list_name'], '测') === false) {

			echo '<div class="col-md-2 col-sm-3 col-xs-4">
							<a class="videopic lazy" href="cx131play.php?id='.$data['data'][$i]['vod_id'].'" title="'.$data['data'][$i]['vod_name'].'" data-original="'.$data['data'][$i]['vod_pic'].'" style="background: url(./style/load.gif) no-repeat; background-position:50% 50%; background-size: cover;"><span class="play hidden-xs"></span><span class="score">'.$data['data'][$i]['vod_continu'].'</span></a>
							<div class="title">
								<h5 class="text-overflow"><a href="cxplayyong.php?id='.$data['data'][$i]['vod_id'].'" >'.$data['data'][$i]['vod_name'].'</a></h5>
							</div>
							<div class="subtitle text-muted text-muted text-overflow hidden-xs">'.$data['data'][$i]['vod_actor'].'</div>
						</div>';

		  }}} ?>									
</ul>


				</div>
			</div>
			<div class="hy-page clearfix">
				<ul class="cleafix">
<li ><a href="./index.php">首页</a></li><li ><a href="javascript:history.back()">返回</a></li>		

</ul>
			</div>		</div>
	</div>
</div>
<?php  include 'footer.php';?>
