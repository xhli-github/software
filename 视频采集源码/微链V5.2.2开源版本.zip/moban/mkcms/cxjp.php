<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<?php  include 'head.php';?>
<title>尝鲜视频列表-<?php echo $mkcms_seoname;?></title>
<meta name="keywords" content="视频排行-<?php echo $mkcms_seoname;?>">
<meta name="description" content="<?php echo $mkcms_seoname;?>">
</head>
<body >
<?php include 'header.php'; ?>
<div class="container">
<div class="row"  style="margin-top:10px"><?php echo get_ad(18)?></div>
	<div class="row">



		<div class="hy-layout clearfix" style="margin-top: 0;">
			<div class="hy-switch-tabs active clearfix">
				<span class="text-muted pull-right hidden-xs">如果您喜欢本站请动动小手分享给您的朋友！</span>
				<ul class="nav nav-tabs">
					<li class="active"><a href="#">永久资源列表</a></li>
				</ul>
			</div>
			<div class="hy-video-list">
				<div class="item">
					<ul class="clearfix">
 							<?php

		for($i=0; $i<$pagesize; $i++){
			if (mb_strpos($data['data'][$i]['list_name'], '无') === false) {
            if (mb_strpos($data['data'][$i]['list_name'], '测') === false) {

			echo '<div class="col-md-2 col-sm-3 col-xs-4">
							<a class="videopic lazy" href="cxplayjp.php?id='.$data['data'][$i]['vod_id'].'" title="'.$data['data'][$i]['vod_name'].'" data-original="'.$data['data'][$i]['vod_pic'].'" style="background: url(./style/load.gif) no-repeat; background-position:50% 50%; background-size: cover;"><span class="play hidden-xs"></span></a>
							<div class="title">
								<h5 class="text-overflow"><a href="cxplayjp.php?id='.$data['data'][$i]['vod_id'].'" >'.$data['data'][$i]['vod_name'].'</a></h5>
							</div>
							<div class="subtitle text-muted text-muted text-overflow hidden-xs">'.$data['data'][$i]['vod_actor'].'</div>
						</div>';

		  }}} ?>

						</ul>
				</div>
			</div>
			<div class="hy-page clearfix">
				<ul class="cleafix">
<?php
if($_GET['page'] != 1){
     echo '<li ><a href="?page=1">首页</a></li>';
     echo '<li ><a href="?page=' . ($_GET['page']-1) . '">上一页</a></li>';
     } else {
echo '<li class="disabled"><a href="?page=1">首页</a></li>';
}
if($_GET['page'] == 1){
	echo '';
}else
echo '<li class="disabled"><a>'.($_GET['page']-1).'</a></li>';
echo '<li class="disabled color"><a>'.$_GET['page'].'</a></li>';
if($_GET['page'] == 700){
	echo '';
}else
echo '<li class="disabled"><a>'.($_GET['page']+1).'</a></li>';
if($_GET['page'] < 700){
     echo '<li ><a href="?page=' . ($_GET['page']+1) . '">下一页</a></li>';
     echo '<li ><a href="?page=700">尾页</a></li>';
     } else {
echo '<li class="disabled"><a>尾页</a></li>';
}	 

?></ul>
			</div>		</div>
	</div>
</div>
<?php  include 'footer.php';?>
