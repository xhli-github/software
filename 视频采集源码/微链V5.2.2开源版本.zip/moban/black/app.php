<!DOCTYPE html>
<!--[if IE 7 ]><html class="ie7" lang="zh-cn"><![endif]--><!--[if IE 8 ]><html class="ie8" lang="zh-cn"><![endif]--><!--[if IE 9 ]><html class="ie9" lang="zh-cn"><![endif]--><!--[if (gt IE 9)|!(IE)]><!--><html class="" lang="zh-cn"><!--<![endif]-->     
<head>
<meta charset='utf-8' />
<title><?php echo $mkcms_seoname;?>app下载</title> 
<link rel='stylesheet' href='css/down.css' />
</head><body  ><script>(function(){var a=true;var h=undefined;var g=[];document.getwide=function(){return h};document.onwidechange=function(e,j){g.push(e)};function f(k,e){if(!d(k,e)){var j=k.className,l=(j!="")?" ":"";added=j+l+e;k.className=added}}function i(l,e){if(d(l,e)){var j=" "+l.className+" ",j=j.replace(/(\s+)/gi," "),k=j.replace(" "+e+" "," "),k=k.replace(/(^\s+)|(\s+$)/g,"");l.className=k}}function d(l,e){var j=l.className,k=j.split(/\s+/);x=0;for(x in k){if(k[x]==e){return true}}return false}function c(j){if(h!=j){h=j;for(var e=0;e<g.length;e++){g[e](j)}}}function b(){if(document.body.clientWidth>1239){f(document.body,"g-wide");i(document.body,"g-small");c("wide")}else{i(document.body,"g-wide");f(document.body,"g-small");c("small")}}window.onresize=function(){if(a){a=false;setTimeout(function(){a=true;b()},120)}};b()})();</script>
<div id="doc">
    <div id="cover">
 
        <div class="header g-clear">
            <div class="phone">
                <img src="<?php echo $mkcms_apppic;?>">
            </div>
            <div class="desc">
                <h1 >
                    <img src="<?php echo $mkcms_appbt;?>" alt="影视大全。下载神器，畅看大片！">
                </h1>
                <div class="download clearfix">
                    <div class="down-btns">
                        <a href="" class="btn btn-iphone"></a>
                        <a href="<?php echo $mkcms_appurl;?>" class="btn btn-android"></a>
                    </div>
                    <div class="down-qr">
                        <img src="<?php echo $mkcms_appewm;?>">
                        <p >二维码扫描下载</p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<script type='text/javascript' src='js/down.js'></script><script type='text/javascript'>define("other.jquery",function(){return window.$;});</script></body></html>