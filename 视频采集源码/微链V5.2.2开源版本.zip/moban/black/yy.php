﻿<?php  include 'head.php'?>
<link rel='stylesheet' id='main-css'  href='<?php echo $mkcms_domain;?>css/cxlist2.css' type='text/css' media='all' />


<meta name="keywords" content="美女热舞-神曲-YY-在线播放">
<title><?php echo $mkcms_seoname;?>美女热舞-神曲-YY-在线播放</title>



<?php include 'header.php'; ?>

<section class="container">
<div class="container">
<div class="row"  style="margin-top:0px"></div></div>
		<div class="hy-layout clearfix" style="margin-top: 10px;">
			<div class="hy-switch-tabs active clearfix">
				<span class="text-muted pull-right hidden-xs">如果您喜欢本站请动动小手分享给您的朋友！</span>
				<ul class="nav nav-tabs">
					<li class="active">
		
					<li><a href="./yy.php?list=t10027.html">热舞</a></li>
                  <li><a href="./yy.php?list=t10025.html">动听</a></li>
                  <li><a href="./yy.php?list=t10026.html">说唱</a></li>
                  <li><a href="./yy.php?list=t10028.html">乐器</a></li>
                  <li><a href="./yy.php?list=t10029.html">另类</a></li>
  
		</ul>
</div>
  
   		
<div class="hy-video-list">
				<div class="item">
					<ul class="clearfix">
<div class="m-g">
<div class="b-listtab-main">

<div class="s-tab-main">
<ul class="list g-clear"><ul style="margin-left:65px">
<?php   //    列表
ini_set('user_agent','Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.2; SV1; .NET CLR 1.1.4322)');
if (empty($_GET['list'])) {
$arta= file_get_contents('http://www.yy.com/shenqu/clist/t10025.html');
} else {
$arta= file_get_contents('http://www.yy.com/shenqu/clist/' .$_GET['list']. '');
	}
$uu1 = '#<img  src="(.*?)"   alt="(.*?)">#';
$qq = '#<p class="text">(.*?)</p>#';
$ww = '#<a href="(.*?)" title="(.*?)" class="target-link"   >#';
preg_match_all($uu1,$arta, $lj);
preg_match_all($qq,$arta, $rs);
preg_match_all($ww,$arta, $ee);
$bf = $lj[1];
$mz = $lj[2];
$gk = $rs[1];
$rr = $ee[1];
$tt = $ee[2];
$responsg = str_replace('/shenqu/play/id_','', $rr);
$responsa = str_replace('.html','', $responsg);
foreach ($bf as $gg => $qz1){
?>
<li class='item'>
    <a class='js-tongjic' href='./playy.php?post=<?php echo $responsa[$gg];?>' title='<?php echo $mz[$gg];?>'target='_blank'>
<div class='cover g-playicon'>
<img  src='<?php echo $qz1;?>' style="background: url(./style/load.gif) no-repeat; background-position:50% 50%; background-size: cover;"span class="score"<?php echo $gk[$gg];?>alt='<?php echo $mz[$gg];?>'/>
</div>
<div class='detail'>
<p class='title g-clear'>
 <span class='s1'><?php echo $gk[$gg];?></span>
 <span class='s2'></span></p>
<p class='star'><?php echo $mz[$gg];?></p>
 </div>
</a>
</li>

<?php
}
?>
</ul>

<?php   //    分页
ini_set('user_agent','Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.2; SV1; .NET CLR 1.1.4322)');
if (empty($_GET['list'])) {
$art= file_get_contents('http://www.yy.com/shenqu/clist/t10025.html');
} else {
$art= file_get_contents('http://www.yy.com/shenqu/clist/' .$_GET['list']. '');
	}
$ii = '#<ul class="pagination clf">([\s\S]+?)</ul>#';
preg_match_all($ii,$art, $lj);
$bf = $lj[1];
$response = str_replace("<li>","", $bf);
$responsf = str_replace("</li>","", $response);
$responsj = str_replace('class="prev"','',$responsf);
$responsg = str_replace('class="next"','', $responsj);
$responsh = str_replace('href="/shenqu/clist/','href="yy.php?list=', $responsg);
foreach ($responsh as $gf => $responsi){
?>
<?php
		if (!$_GET["sousuo"]) {
			$pageon = $pageon + 1;
?><div class="paging"><?php echo $responsi;?></div><div class='ew-page'><?php
		}
?>

<?php
}
?></div><div class="asst asst-list-footer"><?php echo $aik["tv_ad"];?></div></section>




<?php
include "footer.php";
?>