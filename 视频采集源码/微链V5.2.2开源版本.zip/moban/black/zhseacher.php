<!DOCTYPE HTML>
<html>
<?php  include 'head.php';?>
<body class="vod-search">
<?php  include 'header.php';?>
<div class="container">
	<div class="row">
		<div class="col-md-12 col-sm-12 hy-main-content">
			<div class="hy-layout clearfix">
				<div class="hy-video-head">
					<span class="text-muted pull-right hidden-xs"></span>
					<h4 class="margin-0">各大资源站搜索到与<span class="text-color"><?php echo $q?></span>相关的影片</h4>
				</div>
				<div class="hy-video-head">
					<span class="text-muted pull-right hidden-xs"></span>
					<h4 class="margin-0">永久片源搜索列表</h4>
				</div>
				<?php foreach($data["data"] as $i =>$name){  ?>
				<div class="hy-video-details active clearfix">
					<div class="item clearfix">
						<dl class="content">
							<dt><a class="videopic" href="cxplayyong.php?id=<?php echo $data["data"][$i]["vod_id"]; ?>" style="background: url(<?php echo $data["data"][$i]["vod_pic"]; ?>) no-repeat; background-position:50% 50%; background-size: cover;"><span class="play hidden-xs"></span></a></dt>
							<dd class="clearfix">
							<div class="head">
								<h3><?php echo $data["data"][$i]["vod_name"]; ?></h3>
							</div>
							<div class="score">
								<div class="star">
									<span class="star-cur" id="score-0"></span>
								</div>
								<span class="branch"></span>
								<script type="text/javascript">
												var str = "0%" 
												document.getElementById("score-0").style.width = (str.replace(".", ""))
										    </script>
							</div>
							<ul>
								<li><span><?php echo $data["data"][$i]["vod_actor"]; ?></span></li>
								
<li><span class="text-muted">简介：</span><?php echo $data["data"][$i]["vod_content"]; ?></li>

							</ul>
							<div class="block">
								<a class="text-muted" href="cxplayyong.php?id=<?php echo $data["data"][$i]["vod_id"]; ?>">查看详情 <i class="icon iconfont icon-right"></i></a>
							</div>
							</dd>
						</dl>
					</div>
				</div>
    <?php }  ?>
				
<div class="hy-video-head">
					<span class="text-muted pull-right hidden-xs"></span>
					<h4 class="margin-0">云播片源搜索列表</h4>
				</div>
    <?php foreach($data["data"] as $i =>$name){  ?>
				<div class="hy-video-details active clearfix">
					<div class="item clearfix">
						<dl class="content">
							<dt><a class="videopic" href="cxplaykb.php?id=<?php echo $data["data"][$i]["vod_id"]; ?>" style="background: url(<?php echo $data["data"][$i]["vod_pic"]; ?>) no-repeat; background-position:50% 50%; background-size: cover;"><span class="play hidden-xs"></span></a></dt>
							<dd class="clearfix">
							<div class="head">
								<h3><?php echo $data["data"][$i]["vod_name"]; ?></h3>
							</div>
							<div class="score">
								<div class="star">
									<span class="star-cur" id="score-0"></span>
								</div>
								<span class="branch"></span>
								<script type="text/javascript">
												var str = "0%" 
												document.getElementById("score-0").style.width = (str.replace(".", ""))
										    </script>
							</div>
							<ul>
								<li><span><?php echo $data["data"][$i]["vod_actor"]; ?></span></li>
								
<li><span class="text-muted">简介：</span><?php echo $data["data"][$i]["vod_content"]; ?></li>

							</ul>
							<div class="block">
								<a class="text-muted" href="cxplaykb.php?id=<?php echo $data["data"][$i]["vod_id"]; ?>">查看详情 <i class="icon iconfont icon-right"></i></a>
							</div>
							</dd>
						</dl>
					</div>
				</div>
    <?php }  ?>
	    <div class="hy-video-head">
					<span class="text-muted pull-right hidden-xs"></span>
					<h4 class="margin-0">131片源搜索列表</h4>
				</div>
	 <?php foreach($data["data"] as $i =>$name){  ?>
				<div class="hy-video-details active clearfix">
					<div class="item clearfix">
						<dl class="content">
							<dt><a class="videopic" href="cx131play.php?id=<?php echo $data["data"][$i]["vod_id"]; ?>" style="background: url(<?php echo $data["data"][$i]["vod_pic"]; ?>) no-repeat; background-position:50% 50%; background-size: cover;"><span class="play hidden-xs"></span></a></dt>
							<dd class="clearfix">
							<div class="head">
								<h3><?php echo $data["data"][$i]["vod_name"]; ?></h3>
							</div>
							<div class="score">
								<div class="star">
									<span class="star-cur" id="score-0"></span>
								</div>
								<span class="branch"></span>
								<script type="text/javascript">
												var str = "0%" 
												document.getElementById("score-0").style.width = (str.replace(".", ""))
										    </script>
							</div>
							<ul>
								<li><span><?php echo $data["data"][$i]["vod_actor"]; ?></span></li>
								
<li><span class="text-muted">简介：</span><?php echo $data["data"][$i]["vod_content"]; ?></li>

							</ul>
							<div class="block">
								<a class="text-muted" href="cx131play.php?id=<?php echo $data["data"][$i]["vod_id"]; ?>">查看详情 <i class="icon iconfont icon-right"></i></a>
							</div>
							</dd>
						</dl>
					</div>
				</div>
    <?php }  ?>
	 <div class="hy-video-head">
					<span class="text-muted pull-right hidden-xs"></span>
					<h4 class="margin-0">135片源搜索列表</h4>
				</div>
	 <?php foreach($data["data"] as $i =>$name){  ?>
				<div class="hy-video-details active clearfix">
					<div class="item clearfix">
						<dl class="content">
							<dt><a class="videopic" href="cx135play.php?id=<?php echo $data["data"][$i]["vod_id"]; ?>" style="background: url(<?php echo $data["data"][$i]["vod_pic"]; ?>) no-repeat; background-position:50% 50%; background-size: cover;"><span class="play hidden-xs"></span></a></dt>
							<dd class="clearfix">
							<div class="head">
								<h3><?php echo $data["data"][$i]["vod_name"]; ?></h3>
							</div>
							<div class="score">
								<div class="star">
									<span class="star-cur" id="score-0"></span>
								</div>
								<span class="branch"></span>
								<script type="text/javascript">
												var str = "0%" 
												document.getElementById("score-0").style.width = (str.replace(".", ""))
										    </script>
							</div>
							<ul>
								<li><span><?php echo $data["data"][$i]["vod_actor"]; ?></span></li>
								
<li><span class="text-muted">简介：</span><?php echo $data["data"][$i]["vod_content"]; ?></li>

							</ul>
							<div class="block">
								<a class="text-muted" href="cx135play.php?id=<?php echo $data["data"][$i]["vod_id"]; ?>">查看详情 <i class="icon iconfont icon-right"></i></a>
							</div>
							</dd>
						</dl>
					</div>
				</div>
    <?php }  ?>
	<!--
<?php 
if (!empty($one)){
foreach ($one as $ni=>$cs){ 
$mvsrc1 = str_replace("http://www.360kan.com", "", "$nine[$ni]");
$pingfen = str_replace('<div class="b-tomato"><div class="rating-site yellow"><p class="value">评分：<span>', '', "$liu[$ni]");
$pingfen = str_replace('</span></p></div></div>', '', "$pingfen");
$pingfen = str_replace('    ', '', "$pingfen");
$pingfen = str_replace('<div class="cont">', '', "$pingfen");
$pingfen = str_replace('<h3 class="title">', '', "$pingfen");
$pingfen = str_replace(array("\r\n", "\r", "\n"), '', "$pingfen");
$pingfen = str_replace('<div class="b-tomato"><div class="rating-site red"><p class="value">评分：<span>', '', "$pingfen");
$pingfen = str_replace('<div class="b-tomato"><div class="rating-site green"><p class="value">评分：<span>', '', "$pingfen");
$jianjie= str_replace("data-desc='", '', "$ba[$ni]");
$jianjie= str_replace("'>", '', "$jianjie");
$tupian=$two[$ni];
if ($mkcms_wei==1){
$chuandi='../../vod'.$mvsrc1;
}
else{
$chuandi='./play.php?play='.$mvsrc1;	
}//结束
$d_scontent=explode(',',$mkcms_shoufei);
for($i=0;$i<count($d_scontent);$i++)
{
if($cs==$d_scontent[$i]){
//提示错误值
$xianshi='style="display:none"';
     }	

}
?>

<div class="hy-video-head">
					<span class="text-muted pull-right hidden-xs"></span>
					<h4 class="margin-0">全网搜索列表(来自爱奇艺/优酷/腾讯/乐视等)</h4>
				</div>	
<div class="hy-video-details active clearfix" <?php echo $xianshi?>>
					<div class="item clearfix">
						<dl class="content">
							<dt><a class="videopic" href="<?php echo $chuandi?>" style="background: url(<?php echo $tupian?>) no-repeat; background-position:50% 50%; background-size: cover;"><span class="play hidden-xs"></span></a></dt>
							<dd class="clearfix">
							<div class="head">
								<h3><?php echo $cs?><?php echo $three[$ni]?></h3>
							</div>
							<div class="score">
								<div class="star">
									<span class="star-cur" id="score-<?php echo $pingfen?>"></span>
								</div>
								<span class="branch"><?php echo $pingfen?></span>
								<script type="text/javascript">
												var str = "<?php echo $pingfen?>%" 
												document.getElementById("score-<?php echo $pingfen?>").style.width = (str.replace(".", ""))
										    </script>
							</div>
							<ul>
								<li><?php echo $si[$ni]?></li>
								<li><?php echo $wu[$ni]?></li>
<li><span class="text-muted">简介：</span><?php echo $jianjie?></li>

							</ul>
							<div class="block">
								<a class="text-muted" href="<?php echo $chuandi?>">查看详情 <i class="icon iconfont icon-right"></i></a>
							</div>
							</dd>
						</dl>
					</div>
				</div>

<?php } 
}else{
	
foreach ($mingxing as $k=>$mx){ 
$mvsrc1 = str_replace("http://www.360kan.com", "", "$mingxing[$k]");
$tupian=$mingxing1[$k];
$title=$mingxing2[$k];
$jishu=$mingxing3[$k];
if ($mkcms_wei==1){
$chuandi='../../vod'.$mvsrc1;
}
else{
$chuandi='./play.php?play='.$mvsrc1;	
}//结束

?>
	
<div class="hy-video-details active clearfix">
					<div class="item clearfix">
						<dl class="content">
							<dt><a class="videopic" href="<?php echo $chuandi?>" style="background: url(<?php echo $tupian?>) no-repeat; background-position:50% 50%; background-size: cover;"><span class="play hidden-xs"></span></a></dt>
							<dd class="clearfix">
							<div class="head">
								<h3><?php echo $title?><?php echo $jishu?></h3>
							</div>

							<ul>
<li><span class="text-muted">主演：</span><?php echo $q?></li>

							</ul>
							<div class="block">
								<a class="text-muted" href="<?php echo $chuandi?>">查看详情 <i class="icon iconfont icon-right"></i></a>
							</div>
							</dd>
						</dl>
					</div>
				</div>-->
<?php } ?> 
<?php } ?> 
				</div>
		</div>
		<div class="col-md-3 col-sm-12 hy-main-side hidden-sm hidden-xs">
			<div class="hy-layout clearfix">
				<div class="hy-video-ranking side clearfix">
					<div class="head">
						<a class="text-muted pull-right" href="<?php echo $mkcms_domain;?>list.php?type=movie">更多 <i class="icon iconfont icon-right"></i></a>
						<h4><i class="icon iconfont icon-top text-color"></i>影片排行榜</h4>
					</div>
					<div class="item">
						<ul class="clearfix">
      <?php 
      foreach ($bdarr[1] as $kurl=>$bd){
          //echo $bd;//name
          $bdurl1=$bdurl[$kurl];//url
		  $bdurl1 = str_replace("http://www.360kan.com", "", "$bdurl1");
          $bdliang1=$bdliang[$kurl];
		   if ($mkcms_wei==1){
$chuandi='./vod'.$bdurl1;
}
else{
$chuandi='./play.php?play='.$bdurl1;	
}
          //echo $bdurl1;
		  echo "<li class='text-overflow '><span class='pull-right text-color'>$bdliang1</span><a href='$chuandi' title='$bd'><em class='number active'>></em>$bd</a></li>";

      }
      
      
      ?>
	  </ul>
					</div>
				</div>

			</div>
		</div>
	</div>
</div>
<script>
	    var swiper = new Swiper('.hy-slide', {
	        pagination: '.swiper-pagination',
	        paginationClickable: true,
	        autoplay: 3000,
	    });	    
	    </script>

<?php  include 'footer.php';?>
