<?php
include('system/inc.php');
?>
<?php  include 'head.php';?>
<title>电视直播 - <?php echo $mkcms_description;?></title>
<meta name="keywords" content="电视直播，<?php echo $mkcms_description;?>，源码开发采集请联系QQ号2248186422">
<meta name="description" content="热剧快播,最好看的剧情片尽在<?php echo $mkcms_description;?>,电视直播">
<style type="text/css">

table {border-collapse:collapse;border-spacing:0}
fieldset,img {border:0}
ol,ul {list-style:none}
.bingdoutv{ width:100%;height:100%;}
.player{ width:80%;height:100%;float:left;margin:0;padding:0}
.list{ width:20%;height:100%; float:right;}
</style>
</head>
<body class="vod-type apptop">

<?php include 'header.php'; ?>
<div class="container">
<div class="row">
<div class="container">
<div class="row"  style="margin-top:10px">
</div>
</div>
<div class="hy-layout clearfix" style="margin-top: 10px;">
            <div class="hy-switch-tabs active clearfix">
				<span class="text-muted pull-right hidden-xs">如果您喜欢本站请动动小手分享给您的朋友！</span>
				<ul class="nav nav-tabs">
					<li class="active"><a href="">电视直播平台</a></li>
				</ul>
			</div>

<div class="row"  style="margin-top:10px"></div>
	<div class="row">
		<div class="hy-player clearfix">
			<div class="item">
				<div class="col-md-9 col-sm-12 padding-0">
					<div class="info embed-responsive">
					<?php
function getrealurl($url){
	$header = get_headers($url,1);
	if (strpos($header[0],'301') || strpos($header[0],'302')) {
		if(is_array($header['Location'])) {
			return $header['Location'][count($header['Location'])-1];
		}else{
			return $header['Location'];
		}
	}else {
		return $url;
	}
}
 
$url= $_GET['url'];
if(strpos($url,'rtmp') !== false){ 
 $url2 = $url; 
}else{
 $url2 = getrealurl($url); 
}
?>
<div id="shiping_box"></div>
<script type="text/javascript"> 

          function run(){
        var s = document.getElementById("timer");      
        if(!s){          
            return false;
        }else{
          s.innerHTML = s.innerHTML * 1 - 1;
        }
        
    }
    window.setInterval("run();", 1000);
	$('#shiping_box').html('<div style="text-align:center;width:100%;"></div><div id="timer">0</div>');
    //设置延时函数
    function adsUp(){    
        $("#shiping_box").html('<iframe allowFullscreen="true" src=""  id="video" style="width:100%;border:none" allowtransparency="true" allowfullscreen="true" frameborder="0" scrolling="no"></iframe>');  
    }
    //五秒钟后自动收起
    var t = setTimeout(adsUp,<?php echo $pucms_miaoshu*1000;?>); 
    
</script>

</div>

					<div class="footer clearfix">

						<ul class="cleafix hidden-sm hidden-xs">
						

						
						

						</ul>


					</div>
	<span class="text-muted" id="xuji"></span>
					</div>
					
									<div class="col-md-3 col-sm-12 padding-0">
					<div class="sidebar">
						<div class="hy-play-list play">
							<div class="item tyui" id="dianshijuid">
								<div class="panel clearfix">
									<a class="option collapsed" data-toggle="collapse" data-parent="#playlist" href="#playlist1">点击播放<span class="text-muted pull-right"><i class="icon iconfont icon-right"></i></span></a>
									<div id="playlist1" class="playlist collapse in dianshijua">
										<ul class="playlistlink-1 list-15256 clearfix now">
<li><a href="ck/?url=http://zhibo.hkstv.tv/livestream/zb2yhapo/playlist.m3u8" class="hy-index-tags hidden-md clearfix" target="iframe-player">香港TVB</a></li>
<li><a href="ck/?url=http://hls-ott-zhibo.wasu.tv/live/97_68611/index.m3u8" class="hy-index-tags hidden-md clearfix" target="iframe-player">电视剧直播</a></li> 
<li><a href="ck/?url=http://live.yjbc.tv:8081/live/smil:yjtv2.smil/playlist.m3u8" class="hy-index-tags hidden-md clearfix" target="iframe-player">阳江频道1</a></li>
<li><a href="ck/?url=http://live.yjbc.tv:8081/live/smil:yjtv1.smil/playlist.m3u8" class="hy-index-tags hidden-md clearfix" target="iframe-player">阳江频道2</a></li>
<li><a href="ck/?url=http://dslive.grtn.cn:80/4K/sd/live.m3u8" class="hy-index-tags hidden-md clearfix" target="iframe-player">广东综艺</a></li>
<li><a href="ck/?url=http://dslive.grtn.cn/mmzh/sd/live.m3u8" class="hy-index-tags hidden-md clearfix" target="iframe-player">茂名频道</a></li>
<li><a href="ck/?url=http://dslive.grtn.cn/jmzh/sd/live.m3u8" class="hy-index-tags hidden-md clearfix" target="iframe-player">江门频道</a></li>
<li><a href="ck/?url=http://dslive.grtn.cn/yfzh/sd/live.m3u8" class="hy-index-tags hidden-md clearfix" target="iframe-player">云浮频道</a></li>
<li><a href="ck/?url=http://dslive.grtn.cn/zjzh/sd/live.m3u8" class="hy-index-tags hidden-md clearfix" target="iframe-player">湛江频道</a></li>
<li><a href="ck/?url=http://hlslive.n21.cc/tm0Or7U/1500/live.m3u8" class="hy-index-tags hidden-md clearfix" target="iframe-player">珠海频道</a></li>
<li><a href="ck/?url=http://live.zscz0768.com/live/ggpd.m3u8" class="hy-index-tags hidden-md clearfix" target="iframe-player">潮州公共</a></li>
<li><a href="ck/?url=http://live.zscz0768.com/live/zhgg.m3u8" class="hy-index-tags hidden-md clearfix" target="iframe-player">潮州综合</a></li>
<li><a href="ck/?url=http://dslive.grtn.cn/hzzh/sd/live.m3u8" class="hy-index-tags hidden-md clearfix" target="iframe-player">惠州频道</a></li>
<li><a href="ck/?url=http://dslive.grtn.cn/hyzh/sd/live.m3u8" class="hy-index-tags hidden-md clearfix" target="iframe-player">河源频道</a></li>
<li><a href="ck/?url=http://pdlive.lyuncloud.com/pdlive/pdtv/index.m3u8" class="hy-index-tags hidden-md clearfix" target="iframe-player">上海浦东</a></li>
<li><a href="ck/?url=http://live.setv.sh.cn/slive/shedu02_1200k.m3u8" class="hy-index-tags hidden-md clearfix" target="iframe-player">上海教育</a></li>
<li><a href="ck/?url=http://stream.ysbtv.net/1/sd/live.m3u8" class="hy-index-tags hidden-md clearfix" target="iframe-player">青海频道</a></li>
<li><a href="ck/?url=http://live.ybtvyun.com/video/s10006-ybtv1-sd/index.m3u8" class="hy-index-tags hidden-md clearfix" target="iframe-player">吉林TV1</a></li>
<li><a href="ck/?url=http://live.ybtvyun.com/video/s10006-ybtv2-sd/index.m3u8" class="hy-index-tags hidden-md clearfix" target="iframe-player">吉林TV2</a></li>
<li><a href="ck/?url=http://stream2.jlntv.cn/jilin1/sd/live.m3u8" class="hy-index-tags hidden-md clearfix" target="iframe-player">吉林新闻</a></li>
<li><a href="ck/?url=http://stream2.jlntv.cn/tonghua1/sd/live.m3u8" class="hy-index-tags hidden-md clearfix" target="iframe-player">吉林通化</a></li>
<li><a href="ck/?url=http://ivi.bupt.edu.cn/hls/btv1hd.m3u8" class="hy-index-tags hidden-md clearfix" target="iframe-player">BTV1</a></li><li><a href="ck/?url=http://ivi.bupt.edu.cn/hls/btv2hd.m3u8" class="hy-index-tags hidden-md clearfix" target="iframe-player">BTV2</a></li>
<li><a href="ck/?url=http://ivi.bupt.edu.cn/hls/btv11hd.m3u8" class="hy-index-tags hidden-md clearfix" target="iframe-player">BTV综合</a></li><li><a href="ck/?url=http://ivi.bupt.edu.cn/hls/hunanhd.m3u8" class="hy-index-tags hidden-md clearfix" target="iframe-player">湖南卫视</a></li>
<li><a href="ck/?url=http://ivi.bupt.edu.cn/hls/zjhd.m3u8" class="hy-index-tags hidden-md clearfix" target="iframe-player">浙江卫视</a></li><li><a href="ck/?url=http://ivi.bupt.edu.cn/hls/jshd.m3u8" class="hy-index-tags hidden-md clearfix" target="iframe-player">纪实频道</a></li><li><a href="ck/?url=http://ivi.bupt.edu.cn/hls/dfhd.m3u8" class="hy-index-tags hidden-md clearfix" target="iframe-player">东方卫视</a></li>
<li><a href="ck/?url=http://ivi.bupt.edu.cn/hls/ahhd.m3u8" class="hy-index-tags hidden-md clearfix" target="iframe-player">安徽卫视</a></li>
<li><a href="ck/?url=http://ivi.bupt.edu.cn/hls/hljhd.m3u8" class="hy-index-tags hidden-md clearfix" target="iframe-player">综合新闻</a></li>
<li><a href="ck/?url=http://ivi.bupt.edu.cn/hls/lnhd.m3u8" class="hy-index-tags hidden-md clearfix" target="iframe-player">辽宁卫视</a></li>
<li><a href="ck/?url=http://ivi.bupt.edu.cn/hls/szhd.m3u8" class="hy-index-tags hidden-md clearfix" target="iframe-player">深圳卫视</a></li>
<li><a href="ck/?url=http://ivi.bupt.edu.cn/hls/gdhd.m3u8" class="hy-index-tags hidden-md clearfix" target="iframe-player">广东卫视</a></li>
<li><a href="ck/?url=http://ivi.bupt.edu.cn/hls/tjhd.m3u8" class="hy-index-tags hidden-md clearfix" target="iframe-player">天津卫视</a></li>
<li><a href="ck/?url=http://ivi.bupt.edu.cn/hls/hbhd.m3u8" class="hy-index-tags hidden-md clearfix" target="iframe-player">淮东卫视</a></li>
<li><a href="ck/?url=http://ivi.bupt.edu.cn/hls/sdhd.m3u8" class="hy-index-tags hidden-md clearfix" target="iframe-player">山东卫视</a></li>
<li><a href="ck/?url=http://ivi.bupt.edu.cn/hls/cqhd.m3u8" class="hy-index-tags hidden-md clearfix" target="iframe-player">重庆卫视</a></li>
<li><a href="ck/?url=http://ivi.bupt.edu.cn/hls/cctv1.m3u8" class="hy-index-tags hidden-md clearfix" target="iframe-player">CCTV1</a></li>
<li><a href="ck/?url=http://ivi.bupt.edu.cn/hls/cctv2.m3u8" class="hy-index-tags hidden-md clearfix" target="iframe-player">CCTV2</a></li>
<li><a href="ck/?url=http://ivi.bupt.edu.cn/hls/cctv3.m3u8" class="hy-index-tags hidden-md clearfix" target="iframe-player">CCTV3</a></li>
<li><a href="ck/?url=http://ivi.bupt.edu.cn/hls/cctv4.m3u8" class="hy-index-tags hidden-md clearfix" target="iframe-player">CCTV4</a></li>
<li><a href="ck/?url=http://ivi.bupt.edu.cn/hls/cctv5phd.m3u8" class="hy-index-tags hidden-md clearfix" target="iframe-player">CCTV5</a></li>
<li><a href="ck/?url=http://ivi.bupt.edu.cn/hls/cctv6hd.m3u8" class="hy-index-tags hidden-md clearfix" target="iframe-player">CCTV6HD</a></li>
<li><a href="ck/?url=http://ivi.bupt.edu.cn/hls/cctv6.m3u8" class="hy-index-tags hidden-md clearfix" target="iframe-player">CCTV6</a></li>
<li><a href="ck/?url=http://ivi.bupt.edu.cn/hls/cctv7.m3u8" class="hy-index-tags hidden-md clearfix" target="iframe-player">CCTV7</a></li><li><a href="ck/?url=http://ivi.bupt.edu.cn/hls/cctv8.m3u8" class="hy-index-tags hidden-md clearfix" target="iframe-player">CCTV8</a></li><li><a href="ck/?url=http://ivi.bupt.edu.cn/hls/cctv9.m3u8" class="hy-index-tags hidden-md clearfix" target="iframe-player">CCTV9</a></li>
<li><a href="ck/?url=http://ivi.bupt.edu.cn/hls/cctv10.m3u8" class="hy-index-tags hidden-md clearfix" target="iframe-player">CCTV10</a></li>
<li><a href="ck/?url=http://ivi.bupt.edu.cn/hls/cctv11.m3u8" class="hy-index-tags hidden-md clearfix" target="iframe-player">CCTV11</a></li><li><a href="ck/?url=http://ivi.bupt.edu.cn/hls/cctv12.m3u8" class="hy-index-tags hidden-md clearfix" target="iframe-player">CCTV12</a></li><li><a href="ck/?url=http://ivi.bupt.edu.cn/hls/cctv13.m3u8" class="hy-index-tags hidden-md clearfix" target="iframe-player">CCTV13</a></li><li><a href="ck/?url=http://ivi.bupt.edu.cn/hls/cctv14.m3u8" class="hy-index-tags hidden-md clearfix" target="iframe-player">CCTV14</a></li><li><a href="ck/?url=http://ivi.bupt.edu.cn/hls/cctv15.m3u8" class="hy-index-tags hidden-md clearfix" target="iframe-player">CCTV15</a></li><li><a href="ck/?url=http://ivi.bupt.edu.cn/hls/cctv16.m3u8" class="hy-index-tags hidden-md clearfix" target="iframe-player">CCTV16</a></li><li><a href="ck/?url=http://ivi.bupt.edu.cn/hls/btv1.m3u8" class="hy-index-tags hidden-md clearfix" target="iframe-player">BTV1标清</a></li><li><a href="ck/?url=http://ivi.bupt.edu.cn/hls/btv2.m3u8" class="hy-index-tags hidden-md clearfix" target="iframe-player">BTV2标清</a></li>
<li><a href="ck/?url=http://wfc.bonus-tv.ru:80/cdn/wfcint/tracks-v2a1/index.m3u8" class="hy-index-tags hidden-md clearfix" target="iframe-player">时装台WFC</a></li>
<li><a href="ck/?url=http://cmctv.ios.internapcdn.net/cmctv_vitalstream_com/live_1/CMCUSA/chunklist.m3u8" class="hy-index-tags hidden-md clearfix" target="iframe-player">加州音悦台</a></li>
<li><a href="ck/?url=http://hls.shansontv.cdnvideo.ru/shansontv/smil:shansontv.smil/playlist.m3u8" class="hy-index-tags hidden-md clearfix" target="iframe-player">俄罗斯1ShansonTV</a></li><li><a href="ck/?url=http://chanson-video.hostingradio.ru:8080/hls/chansonabr/live.m3u8" class="hy-index-tags hidden-md clearfix" target="iframe-player">俄罗斯2ShansonTV</a></li>
<li><a href="ck/?url=http://tvcom.stream.intelema.ru/tvcom/studio/index.m3u8" class="hy-index-tags hidden-md clearfix" target="iframe-player">俄罗斯Tivikom</a></li>
<li><a href="ck/?url=http://streaming.astrakhan.ru/astrakhan24/index.m3u8" class="hy-index-tags hidden-md clearfix" target="iframe-player">俄罗斯Astrakhan</a></li>
<li><a href="ck/?url=https://n24-cdn-live.ntv.co.jp/ch01/High.m3u8" class="hy-index-tags hidden-md clearfix" target="iframe-player">Japan24news</a></li>
<li><a href="ck/?url=http://hls.mirtv.cdnvideo.ru/mirtv-parampublish/hd/playlist.m3u8" class="hy-index-tags hidden-md clearfix" target="iframe-player">俄羅斯Mirtv</a></li>
<li><a href="ck/?url=http://vid.techbee.pro:8080/1tvcrimea/tracks-v1a1/index.m3u8" class="hy-index-tags hidden-md clearfix" target="iframe-player">烏克蘭</a></li>
<li><a href="ck/?url=http://vid.techbee.pro:8080/1tvcrimea/index.m3u8" class="hy-index-tags hidden-md clearfix" target="iframe-player">烏克蘭3</a></li>
<marquee direction="left">欢迎光临<?php echo $mkcms_description;?>，关注本网站，更多精彩影视资讯等着你来观看。</marquee>

			</ul>
									</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>
<script type="text/javascript">
	var al = $('.dianshijua a');
	al.attr('class','am-btn am-btn-default lipbtn');
	var ji= new Array();
	var btnji= new Array();
	for(var g=0;g<al.length;g++){
		ji.push(al[g].href);
		btnji.push(al[g].id);
		al[g].href = 'javascript:void(0)';
		al[g].target = '_self';
		al.eq(g).attr('onclick','bofang(\''+ji[g]+'\',\''+btnji[g]+'\')');
	};
</script>
<script type="text/javascript">
var tishi = ('正在为您播放-电视直播');
document.getElementById('xuji').innerHTML = tishi;
	function bofang(mp4url,jiid){
		var tishi = ('正在为您播放-电视直播 '+jiid+'');
		document.getElementById('xuji').innerHTML = tishi;
		document.getElementById('video').src=''+mp4url;
		
				//点击之后
document.getElementById('xuji').style.display='block';
document.getElementById('video').style.display='none';
function test() {
			document.getElementById('video').style.display='block';
		}
		setTimeout(test, 0);
	};
</script>

<div class="container">
	<div class="row">
		<div class="col-md-9 col-sm-12 hy-main-content">
		
			<div class="hy-layout clearfix"><div style="margin-top:0px"></div>
				<div class="hy-switch-tabs">
					<ul class="nav nav-tabs">
						<li class="active"><a href="#list3" data-toggle="tab">电视直播台介绍</a></li>
											</ul>
				</div>
				<div class="tab-content">
					<div class="hy-play-list tab-pane fade in active" id="list3">
						<div class="item">
							<div class="plot">
								欢迎大家来到<?php echo $mkcms_description;?>！在线观看电视直播，如果播放有问题,请点击<a href='./book.php'style="color:#ff9900">☞留言☜</a>反馈给我们。好用请推荐给你的朋友！</div>
						</div>
					</div>
				</div>
			</div>
			
			<div class="hy-layout clearfix">
				<div class="hy-video-head">
					<h3 class="margin-0">影片评论</h3>
				</div>
				<div class="ff-forum" id="ff-forum" data-id="37432" data-sid="1">
<?php echo $mkcms_changyan; ?>
</div>
</div>
			</div>
		</div>
		<div class="col-md-3 col-sm-12 hy-main-side hidden-sm hidden-xs">
			<div class="hy-layout clearfix">
				<div class="hy-details-qrcode side clearfix">
					<div class="item">
						<h5 class="text-muted">扫一扫用手机观看</h5>
						<p>
						<img src="images/ew.png" width="250">
						</p>
						<p class="text-muted">
							分享到朋友圈
						</p>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>
					
<span class="ff-hits" id="ff-hits-insert" data-id="37432" data-sid="vod" data-type="insert"></span>		<script>
	    var swiper = new Swiper('.hy-switch', {
	        pagination: '.swiper-pagination',
	        paginationClickable: true,
	        slidesPerView: 5,
	        spaceBetween: 0,
	        nextButton: '.swiper-button-next',
	        prevButton: '.swiper-button-prev',
	        breakpoints: {
	            1200: {
	                slidesPerView: 4,
	                spaceBetween: 0
	            },
	            767: {
	                slidesPerView: 3,
	                spaceBetween: 0					            
	            }
	        }
	    });	 
	    </script>
<span class="ff-record-set" data-sid="1" data-id="37432" data-id-sid="1" data-id-pid="1">
</span>

<?php include 'footer.php'; ?>
