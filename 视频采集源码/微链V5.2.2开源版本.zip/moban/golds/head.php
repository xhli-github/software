<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="renderer" content="webkit|ie-comp|ie-stand">
<meta http-equiv="X-UA-Compatible" content="IE=edge" />
<meta content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0;" name="viewport" />
<meta http-equiv="Cache-Control" content="no-cache, no-store, must-revalidate" />
<meta http-equiv="Pragma" content="no-cache" />
<meta http-equiv="Expires" content="0" />
<link rel="shortcut icon" href="favicon.ico" type="image/x-icon" />
<!--[if lt IE 9]>
<script src="style/html5shiv/3.7.2/html5shiv.min.js"></script>
<script src="style/respond/1.4.2/respond.min.js"></script>
<![endif]-->
<link href="style/css/bootstrap.min.css" rel="stylesheet" type="text/css" />				
<link href="style/css/swiper.min.css" rel="stylesheet" type="text/css" >		
<link href="style/font/iconfont.css" rel="stylesheet" type="text/css" />
<link href="style/css/golds.css" rel="stylesheet" type="text/css" />
<link href="style/css/style.min.css" rel="stylesheet" type="text/css" />
<script src="style/jquery/1.11.3/jquery.min.js"></script>
<script type="text/javascript" src="style/js/bootstrap.min.js"></script>		
<script src="style/js/function.js"></script>
<script type='text/javascript' src="style/js/LazyLoad.js"></script>
<script type='text/javascript' src="style/js/swiper.min.js"></script>
<script type="text/javascript " src="style/js/history.js "></script>
<script>
var _hmt = _hmt || [];
(function() {
  var hm = document.createElement("script");
  hm.src = "https://hm.baidu.com/hm.js?eed641a0f69e62b88baa55eff3bc60e8";
  var s = document.getElementsByTagName("script")[0]; 
  s.parentNode.insertBefore(hm, s);
})();
</script>	
<style type="text/css">

body{
background-repeat:repeat;background-size:inherit;background-attachment:fixed;background-position:center center;background: url(<?php echo $mkcms_beijing;?>); 
}
@media (max-width: 767px){
    body:before{background: url() center 0 no-repeat; background-attachment: fixed;background-size: cover;} 
}
</style>

