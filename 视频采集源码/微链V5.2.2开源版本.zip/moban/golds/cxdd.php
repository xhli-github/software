<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<?php  include 'head.php';
$tv='class="active"'?>
<title>抢先影视资源-在线观看-最新影片-最新剧集排行-<?php echo $mkcms_seoname;?></title>
<meta name="keywords" content="追热剧-最新剧集-好看剧集-最新剧集排行,<?php echo $mkcms_keywords;?>">
<meta name="description" content="<?php echo $mkcms_description;?>">
<style>
.hy-head-menu .item .menulist li.act a{ border: 0; background: none; border-bottom: 2px solid #09BB07; color: #09BB07;}
</style>
</head>
<body>
<?php  include 'header.php';?>
<div class="container">
<div class="row">
<div class="hy-layout clearfix">
  <div class="hy-min-screen clearfix">
    <div class="item clearfix">
      <dl class="clearfix">
        <dt class="text-muted">按资源</dt>
        <dd class="clearfix">
											
<a href="zhcx.php" class="acat" style="white-space: pre-wrap;">全部</a>
<a href='./cx.php' class='acat'>酷播片源</a>
														<a href='./cx131.php' class='acat'>OK片源</a>
														<a href='./cxok.php' class='acat'>135片源</a>
														<a href='./cxdd.php' class='acat'>精品片源</a>							
														<a href='./cxbo.php' class='acat'>永久片源</a>
														<a href='./cxyong.php' class='acat'>156片源</a>
														<a href='./cx135.php' class='acat'>C值片源</a>
														<a href='./cxkb.php' class='acat'>131片源</a>	
														<a href='./cxjp.php' class='acat'>最大片源</a>	
														<a href='./cxzk.php' class='acat'>极速片源</a>	
														<a href='./cxgq.php' class='acat'>最快片源</a>	
                                                        <a href='./cxlist.php' class='acat'>速播片源</a>	<a href='./cx.php' class='acat'>酷播片源</a>
														<a href='./cx131.php' class='acat'>OK片源</a>
														<a href='./cxok.php' class='acat'>135片源</a>
														<a href='./cxdd.php' class='acat'>精品片源</a>							
														<a href='./cxbo.php' class='acat'>永久片源</a>
														<a href='./cxyong.php' class='acat'>156片源</a>
														<a href='./cx135.php' class='acat'>C值片源</a>
														<a href='./cxkb.php' class='acat'>131片源</a>	
														<a href='./cxjp.php' class='acat'>最大片源</a>	
														<a href='./cxzk.php' class='acat'>极速片源</a>	
														<a href='./cxgq.php' class='acat'>最快片源</a>	
                                                        <a href='./cxlist.php' class='acat'>速播片源</a>	</dd>
      </dl>
      <dl class="cleafix">
        <dt class="text-muted">按影片</dt>
        <dd class="clearfix">
						<a href="zhcx.php">全部</a>
<a class='acat'  href='./cxzykh.php' target='_self'>科幻片</a>
														<a class='acat'  href='./cxzydz.php' target='_self'>动作片</a>
														<a class='acat'  href='./cxzyjq.php' target='_self'>剧情片</a>
														<a class='acat'  href='./cxzyxj.php' target='_self'>喜剧片</a>							
														<a class='acat'  href='./cxzyaq.php' target='_self'>爱情片</a>
														<a class='acat'  href='./cxzyzz.php' target='_self'>战争片</a>
														<a class='acat'  href='./cxzykb.php' target='_self'>恐怖片</a></dd>
      </dl>
      <dl class="cleafix hidden-sm">
        <dt class="text-muted">按剧情</dt>
        <dd class="clearfix">
						<a href="zhcx.php">全部</a>
<a class='acat'  href='cxzygc.php' target='_self'>国产剧</a><a class='acat'  href='cxzygj.php' target='_self'>港剧</a><a class='acat'  href='cxzyhj.php' target='_self'>韩剧</a><a class='acat'  href='cxzym.php' target='_self'>欧美剧</a><a class='acat'  href='cxzyr.php' target='_self'>日剧</a><a class='acat'  href='cxzyt.php' target='_self'>台剧</a><a class='acat'  href='./cxzytg.php' target='_self'>泰剧</a><a class='acat'  href='./cxzyy.php' target='_self'>越南剧</a></dd>
      </dl>
         <dl class="cleafix hidden-sm">
        <dt class="text-muted">按资源</dt>
        <dd class="clearfix">
						<a href="zhcx.php">全部</a>
<a class='acat'  href='cxzyzy.php' target='_self'>综艺频道</a><a class='acat'  href='cxzydm.php' target='_self'>动漫频道</a><a class='acat'  href='cxzyj.php' target='_self'>记录片</a><a class='acat'  href='cxzyl.php' target='_self'>伦理片</a><a class='acat'  href='cxzys.php' target='_self'>写真视讯</a><a class='acat'  href='cxzyx.php' target='_self'>腿模写真</a><a class='acat'  href='./cxzyn.php' target='_self'>美女写真</a></dd>
      </dl>
            <dl class="cleafix hidden-sm">
        <dt class="text-muted">其他类</dt>
        <dd class="clearfix">
						<a href="javascript:history.back()">返回</a>
<a class='acat'  href='zongyi.php' target='_self'>综艺</a><a class='acat'  href='dongman.php' target='_self'>动漫</a><a class='acat'  href='movie.php' target='_self'>电影</a><a class='acat'  href='tv.php' target='_self'>电视剧</a><a class='acat'  href='vlist.php?cid=0' target='_self'>热映</a><a class='acat'  href='gaoxiao.php' target='_self'>搞笑</a><a class='acat'  href='./yy.php' target='_self'>舞曲</a><a class='acat'  href='./zhibo.php' target='_self'>直播</a></dd>
      </dl>
    </div>
  </div>
</div>

<div class="container">
<div class="row"  style="margin-top:0px"></div></div>
		<div class="hy-layout clearfix" style="margin-top: 10px;">
			<div class="hy-switch-tabs active clearfix">
				<span class="text-muted pull-right hidden-xs">如果您喜欢本站请动动小手分享给您的朋友！</span>
				<ul class="nav nav-tabs">
					<li class="active"><a href="#">精品资源列表</a></li>
				</ul>
			</div>
			<div class="hy-video-list">
				<div class="item">
					<ul class="clearfix">


<?php

		for($i=0; $i<$pagesize; $i++){
			if (mb_strpos($data['data'][$i]['list_name'], '无') === false) {
            if (mb_strpos($data['data'][$i]['list_name'], '测') === false) {

			echo '<div class="col-md-m col-sm-3 col-xs-m">
							<a class="videopic lazy" href="cxplay.php?id='.$data['data'][$i]['vod_id'].'" title="'.$data['data'][$i]['vod_name'].'" data-original="'.$data['data'][$i]['vod_pic'].'" style="background: url(./style/load.gif) no-repeat; background-position:50% 50%; background-size: cover;"><span class="play hidden-xs"></span><span class="score"></span></a>
							<div class="title">
								<h5 class="text-overflow"><a href="cxplay.php?id='.$data['data'][$i]['vod_id'].'" >'.$data['data'][$i]['vod_name'].'</a></h5>
							</div>
							<div class="subtitle text-muted text-muted text-overflow hidden-xs">'.$data['data'][$i]['vod_actor'].'</div>
						</div>';

		  }}} ?>

						</ul>
				</div>
			</div>
			<div class="hy-page clearfix">
				<ul class="cleafix">
<?php
if($_GET['page'] != 1){
     echo '<li ><a href="?page=1">首页</a></li>';
     echo '<li ><a href="?page=' . ($_GET['page']-1) . '">上一页</a></li>';
     } else {
echo '<li class="disabled"><a href="?page=1">首页</a></li>';
}
if($_GET['page'] == 1){
	echo '';
}else
echo '<li class="disabled"><a>'.($_GET['page']-1).'</a></li>';
echo '<li class="disabled color"><a>'.$_GET['page'].'</a></li>';
if($_GET['page'] == 700){
	echo '';
}else
echo '<li class="disabled"><a>'.($_GET['page']+1).'</a></li>';
if($_GET['page'] < 700){
     echo '<li ><a href="?page=' . ($_GET['page']+1) . '">下一页</a></li>';
     echo '<li ><a href="?page=700">尾页</a></li>';
     } else {
echo '<li class="disabled"><a>尾页</a></li>';
}	 

?></ul>
			</div>		</div>
	</div>
</div>
<?php  include 'footer.php';?>
