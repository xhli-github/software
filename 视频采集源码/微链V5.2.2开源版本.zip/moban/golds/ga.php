<?php
include('system/inc.php');
?>
<!DOCTYPE HTML>

<html>
<head>
<?php  include 'moban/golds/head.php'?>
<link rel='stylesheet' id='main-css'  href='css/cxlist.css' type='text/css' media='all' />
<title>综合视频排行-娱乐视频-小视频-视频资讯</title>
<meta name="keywords" content="搞笑排行-自拍达人-小视频-<?php echo $mkcms_description;?>">
<meta name="description" content="搞笑排行-自拍达人-小视频-<?php echo $mkcms_description;?>">
</head>
<body>
<?php include 'moban/golds/header.php'; ?>
<section class="container">
<div class="container">
<div class="row"  style="margin-top:0px"></div></div>
		<div class="hy-layout clearfix" style="margin-top: 10px;">
			<div class="hy-switch-tabs active clearfix">
				<span class="text-muted pull-right hidden-xs">如果您喜欢本站请动动小手分享给您的朋友！</span>
				<ul class="nav nav-tabs">
					<li class="active">
                    <li><a href="?m=c_0_d_1_s_2_p_1">全部</a></li>
                    <li><a href="?m=c_91_d_1_s_2_p_1">资讯频道</a></li>
                    <li><a href="?m=c_177_d_1_s_2_p_1">儿童频道</a></li>
                    <li><a href="?m=c_86_d_1_s_2_p_1">娱乐频道</a></li>
                    <li><a href="?m=c_95_d_1_s_1_p_1">音乐频道</a></li>
                    <li><a href="?m=c_84_d_1_s_2_p_1">纪实频道</a></li>
 <li><a href="?m=c_105_d_1_s_2_p_1">科技频道</a></li>
                   
<li><a href="?m=c_104_d_1_s_2_p_1">汽车频道</a></li>
<li><a href="?m=c_99_d_1_s_2_p_1">游戏频道</a></li>

<li><a href="?m=c_103_d_1_s_2_p_1">生活频道</a></li>

<li><a href="?m=c_88_d_1_s_2_p_1">亲子频道</a></li>
<li><a href="?m=c_171_d_1_s_2_p_1">旅游频道</a></li>
<li><a href="?m=c_89_d_1_s_1">时尚频道</a></li>
<li><a href="?m=c_174_d_1_s_2_p_1">创意频道</a></li>
<li><a href="?m=c_87_d_1_s_2_p_1">拍客频道</a></li>
<li><a href="?m=c_90_d_1_s_2_p_1">教育频道</a></li>
<li><a href="?m=c_vr_d_1_s_1">VR频道</a></li>
<li><a href="?m=c_175_d_1_s_2_p_1">自拍频道</a></li>
<li><a href="?m=c_176_d_1_s_2_p_1">广告频道</a></li>
<li><a href="?m=c_102_d_1_s_2_p_1">微电影</a></li>

                    
                    
                    
                </ul>
			</div>
    <div class="hy-video-list">
				<div class="item">
					<ul class="clearfix">

<?php
if (empty($_GET['m'])) {
	$html = "http://list.youku.com/category/video/c_0_d_1_s_2_p_1";
} else {
	$html = "http://list.youku.com/category/video/" . $_GET["m"];
}
$rurl = file_get_contents($html);
$vname = "#<div class=\"yk-col4 \"><div class=\"yk-pack p-list\" taglog=\"\"><div class=\"p-thumb\"><a href=\"(.*?)\" target=\"_blank\" title=\"(.*?)\"></a><i class=\"bg\"></i><img class=\"quic\"  src=\"(.*?)\" alt=\"(.*?)\"/></div><ul class=\"p-info pos-bottom\"><li class=\"status\"><span class=\"p-time hover-hide\"><i class=\"ibg\"></i><span>(.*?)</span></span></li></ul><ul class=\"info-list\"><li class=\"title\"><a href=\"(.*?)\" target=\"_blank\" title=\"(.*?)\">(.*?)</a></li><li class=\" \">(.*?)</li></ul></div></div>#";
preg_match_all($vname, $rurl, $xarr);
$xbflist = $xarr[1];
$xname = $xarr[2];
$ximg = $xarr[3];
$shijian = $xarr[5];

foreach ($xname as $key => $xvau) {
	$do = $xbflist[$key];
	$do1 = base64_encode($do);
	$cc = "./splay.php?xplay=";
	$ccb = $cc . $do1;
 echo '<div class="col-md-m col-sm-3 col-xs-m">
							<a class="videopic lazy" href="'.$ccb.'" title="'.$xname[$key].'" data-original="'.$ximg[$key].'" style="background: url(./style/load.gif) no-repeat; background-position:50% 50%; background-size: cover;">
							<span class="play hidden-xs"></span></a>
							<div class="title">
								<h5 class="text-overflow"><a href="'.$ccb.'"'.$shijian[$key].'</a></h5>
							</div>
							<div class="subtitle text-muted text-muted text-overflow hidden-xs">'.$xname[$key].'</div>
	</div>';
 } ?>
</ul>
      </div>
    </div>
</div>

</div>

<div class="paging">
<?php
$curl = curl_init();
curl_setopt($curl, CURLOPT_URL, $html);
curl_setopt($curl, CURLOPT_HEADER, 1);
curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1);
$response = curl_exec($curl);
curl_close($curl);
$response = strstr($response, "<div class=\"yk-pager\">");
$response = strstr($response, "<div class=\"vault-banner", true);
$response = str_replace("<ul class=\"yk-pages\">", "", $response);
$response = str_replace("</ul>", "", $response);
$response = str_replace("//list.youku.com/category/video/", "ga.php?m=", $response);
$response = str_replace("<li>", "", $response);
$response = str_replace("</li>", "", $response);
$response = str_replace("<li", "<a", $response);
$response = str_replace("<a class=\"next\" title=\"下一页\">", "", $response);
echo $response;
?>
</div>
</section>

<?php include "moban/golds/footer.php";?>
</body>
