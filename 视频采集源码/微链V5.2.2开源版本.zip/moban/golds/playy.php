<?php
error_reporting(0);
include "./system/inc.php";
$zhan = $aik["zhanwai"];
$url = $_SERVER["HTTP_HOST"];
$jiejie = substr($url, 0 - 7, 7);
$jia0 = base64_encode($jiejie);
$jia = md5($jia0);
$b = strpos($jia, "a");
$c = strpos($jia, "z");
$ye = substr($jia, $b, $b - $c - 1);
$jia1 = md5($jia);
$d = strpos($jia1, "s");
$e = strpos($jia1, "0");
$ye1 = substr($jia1, $d, $d - $e - 3);
$jia3 = base64_encode($ye1);
$jia2 = md5($jia3);
$f = strpos($jia2, "W");
$g = strpos($jia2, "5");
$ye2 = substr($jia2, $f, $f - $g - 5);
$jiami0 = $ye1 . $ye2 . $ye;
$jiami = base64_encode($jiami0);

$link = $_GET["play"];
$url_array = explode("/", $link);
$player = "http://www.360kan.com" . $link;
$tvinfo = file_get_contents($player);
$tvzz = "#<div class=\"num-tab-main g-clear\\s*js-tab\"\\s*(style=\"display:none;\")?>[\\s\\S]+?<a data-num=\"(.*?)\" data-daochu=\"to=(.*?)\" href=\"(.*?)\">[\\s\\S]+?</div>#";
$tvzz1 = "#<a data-num=\"(.*?)\" data-daochu=\"to=(.*?)\" href=\"(.*?)\">#";
$bflist = "#<a data-daochu=\"to=(.*?)\" class=\"btn js-site ea-site ea-site-(.*?)\" href=\"(.*?)\">(.*?)</a>#";
$jianjie = "#<p class=\"item-desc js-open-wrap\">(.*?)</p>#";
$biaoti = "#<h1>(.*?)</h1>#";
$zytimu = "#<ul class=\"list w-newfigure-list g-clear js-year-page\" style=\"display:block;\">\r\n                (.*?)\r\n            </ul>#";
$bofang = "#<a data-daochu=\"(.*?)\" class=\"btn js-site ea-site (.*?)\" href=\"(.*?)\">(.*?)</a>\r\n#";
preg_match_all($jianjie, $tvinfo, $jjarr);
preg_match_all($tvzz, $tvinfo, $tvarr);
preg_match_all($pan, $tvinfo, $ptvarr);
preg_match_all($pan1, $tvinfo, $ptvarr1);
preg_match_all($bflist, $tvinfo, $tvlist);
preg_match_all($biaoti, $tvinfo, $btarr);
preg_match_all($zytimu, $tvinfo, $zybtarr);
preg_match_all($bofang, $tvinfo, $bfarr);
$mvsrc = $tvlist[3];
$bflu = $tvlist[1];
$bfyuan = $tvlist[4];
$jian = $jjarr[1][0];
$timu = $btarr[1][0];
$zybiaoti = $zybtarr[1][0];
$mvsrc1 = str_replace("http://cps.youku.com/redirect.html?id=0000028f&url=", "", $mvsrc);
$zcf = implode($glue, $tvarr[0]);
preg_match_all($tvzz1, $zcf, $tvarr1);
$jishu = $tvarr1[1];
$b = $tvarr1[3];
$much = 1;
if ($url_array[1] == "tv") {
	$url = $player;
	$array = explode("/", $url);
	$dsjid = $array[4];
	$ch = curl_init($url);
	curl_setopt($ch, CURLOPT_HEADER, 0);
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	curl_setopt($ch, CURLOPT_USERAGENT, "Dalvik/1.6.0 (Linux; U; Android 4.1.4; DROID RAZR HD Build/9.8.1Q-62_VQW_MR-2)");
	curl_setopt($ch, CURLOPT_REFERER, "-");
	$html = curl_exec($ch);
	curl_close($ch);
	$str = $html;
}
?>

<!DOCTYPE HTML>





<?php  include 'head.php'?>

<meta name="keywords" content="美女热舞-神曲-YY-在线播放-播放页">
<title>正在播放-<?php echo $mz[$gg];?>美女热舞-神曲-YY-在线播放</title>


<?php
ini_set('user_agent','Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.2; SV1; .NET CLR 1.1.4322)');

$arta= file_get_contents('http://www.yy.com/shenqu/show/info.do?resid=' .$_GET['post']. '');

$uu1 = '#"resurl":"(.*?)"#';

preg_match_all($uu1,$arta, $lj);

$bf = $lj[1];

foreach ($bf as $gg => $qz1){
?>








<body class="vod-type apptop">

<?php include 'header.php'; ?>


<div class="container">

<div class="row">

<div class="container">

<div class="row"  style="margin-top:10px">
<?php echo get_ad(14)?>
</div>
</div>

<div class="hy-layout clearfix" style="margin-top: 10px;">

<div class="hy-switch-tabs active clearfix">
				
<span class="text-muted pull-right hidden-xs">如果您喜欢本站请动动小手分享给您的朋友！</span>
				
<ul class="nav nav-tabs">
					
<li class="active"><a href=""><?php echo $mz[$gg];?>美女热舞-神曲-YY-在线播放</a></li>
				
</ul>
			
</div>
			

<div class="row"  style="margin-top:10px"><?php echo get_ad(2)?></div>
	<div class="row">
		<div class="hy-player clearfix">
			<div class="item">
				<div class="col-md-9 col-sm-12 padding-0">
					<div class="info embed-responsive">
<div id="shiping_box"></div>
<script type="text/javascript"> 

          function run(){
        var s = document.getElementById("timer");      
        if(!s){          
            return false;
        }else{
          s.innerHTML = s.innerHTML * 1 - 1;
        }
        
    }
    window.setInterval("run();", 1000);
	$('#shiping_box').html('<div style="text-align:center;width:100%;"></div><div id="timer">0</div>');
    //设置延时函数
    function adsUp(){    
        $("#shiping_box").html('<iframe allowFullscreen="true" src="./ck/?url=<?php echo $qz1;?>"  id="video" style="width:100%;border:none" allowtransparency="true" allowfullscreen="true" frameborder="0" scrolling="no"></iframe>');  
    }
    //五秒钟后自动收起
    var t = setTimeout(adsUp,<?php echo $mkcms_miaoshu*1000;?>); 
    
</script>

		
</div>

					<div class="footer clearfix">

						<ul class="cleafix hidden-sm hidden-xs">
						

						
						

						</ul>


					</div>
	<span class="text-muted" id="xuji"></span>
					</div>
					
									<div class="col-md-3 col-sm-12 padding-0">
					<div class="sidebar">
						<div class="hy-play-list play">
							<div class="item tyui" id="dianshijuid">
								<div class="panel clearfix">
									<a class="option collapsed" data-toggle="collapse" data-parent="#playlist" href="#playlist1">点击播放<span class="text-muted pull-right"><i class="icon iconfont icon-right"></i></span></a>
									<div id="playlist1" class="playlist collapse in dianshijua">
										<ul class="playlistlink-1 list-15256 clearfix now">
<li><a href="./ck/?url=http://godsong.bs2dl.yy.com/djdmMjU2YTI5Mzg3ZTUzMTNiN2E3YWFjNjRkYzk3NmY3MTkxODc2ODA2MjdtYg" class="hy-index-tags hidden-md clearfix" target="iframe-player">YY神曲推荐视频</a></li>
<li><a href="./ck/?url=http://godsong.bs2dl.yy.com/dmNhNmYzYzAxNmQ3YjM4MzI1ZmE0OWM0YWExOTA3MjgxMTkxODQ2ODI5OTdtYQ" class="hy-index-tags hidden-md clearfix" target="iframe-player">YY神曲推荐视频</a></li>
<li><a href="./ck/?url=http://godsong.bs2dl.yy.com/djY2ODY3NDAyMTMyZDA3ZThjMTYxOTM0MWM0ODc2MTM2MTkxODE2NzIyOTJtYw" class="hy-index-tags hidden-md clearfix" target="iframe-player">YY神曲推荐视频</a></li>

<marquee direction="left"><?php echo $mkcms_gonggao?></marquee>		

			</ul>
									</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>
<script type="text/javascript">
	var al = $('.dianshijua a');
	al.attr('class','am-btn am-btn-default lipbtn');
	var ji= new Array();
	var btnji= new Array();
	for(var g=0;g<al.length;g++){
		ji.push(al[g].href);
		btnji.push(al[g].id);
		al[g].href = 'javascript:void(0)';
		al[g].target = '_self';
		al.eq(g).attr('onclick','bofang(\''+ji[g]+'\',\''+btnji[g]+'\')');
	};
</script>
<script type="text/javascript">
var tishi = ('正在播放-美女热舞-神曲-YY-在线播放');
document.getElementById('xuji').innerHTML = tishi;
	function bofang(mp4url,jiid){
		var tishi = ('正在播放-美女热舞-神曲-YY-在线播放 '+jiid+'');
		document.getElementById('xuji').innerHTML = tishi;
		document.getElementById('video').src=''+mp4url;
		
				//点击之后
document.getElementById('xuji').style.display='block';
document.getElementById('video').style.display='none';
function test() {
			document.getElementById('video').style.display='block';
		}
		setTimeout(test, 0);
	};
</script>
<?php
}
?>	
	

</div>

	<script type="text/javascript">
function xldata(urls){
	var videourls = document.getElementById('video');
	var xlqieh = document.getElementById('videourlgo');
	videourls.src = urls+xlqieh.href;
}
</script>

<div style="clear: both;"></div> 
<div id="xuji"></div>
<?php echo $aik["tishi_ad"];?><div id="fade" class="black_overlay"> 
</div> 
<div class="video-list view-font">
<script type="text/javascript">
	var al = $('.num-tab-main a');
	al.attr('class','am-btn am-btn-default lipbtn');
	var ji= new Array();
	var btnji= new Array();
	for(var g=0;g<al.length;g++){
		ji.push(al[g].href);
		btnji.push(al[g].id);
		al[g].href = 'javascript:void(0)';
		al[g].target = '_self';
		al.eq(g).attr('onclick','bofang(\''+ji[g]+'\',\''+btnji[g]+'\')');
	};
	 if($("div").hasClass("js-tab-main")){ 
	var taba = $('.js-tab-main a');
	for(var g=0;g<taba.length;g++){
		taba.eq(g).attr('onclick','tabqh(\''+[g]+'\')');
	};
	var numtba = $('.num-tab .num-tab-main');
	for(var g=0;g<numtba.length;g++){
		numtba.eq(g).attr('id','num'+[g]);
	};
	document.getElementById('num1').style.display = 'block';
	function tabqh(ylen){
		var idylen = parseInt(ylen);
		var tabalen = $('.js-tab-main a').length;
		for (var xcyh=0;xcyh<tabalen;xcyh++) {
			document.getElementById('num'+xcyh).style.display = 'none';
		}
		document.getElementById('num'+idylen).style.display = 'block';
	}
	 }
</script>












<script>
var store = $.AMUI.store;var lishi = $('#xuji1').html();store.set('site','<?php echo $timu;?>');      	 store.set('siteurl','<?php echo $_SERVER["REQUEST_URI"];?>');store.set('li',viewji)</script>
<script type="text/javascript">
 var temp = {type: "video", name: "<?php echo $timu;?>",url: "<?php echo $_SERVER["REQUEST_URI"];?>"};			
var histemp = store.get('history')? store.get('history'): [];
       for(var i=0; i<histemp.length; i++) {
            if(histemp[i].type == "video" && histemp[i].url == "<?php echo $_SERVER["REQUEST_URI"];?>") {
                histemp.splice(i, 1); 
                break;
            }
        }
histemp.unshift(temp); 
store.set('history', histemp);
//alert(JSON.stringify(store.get("history")));
var doo = store.get("history");
//$("#sc").html('"+store.get('history')+"');
function qc () {
	store.clear();
		
}
		</script>
		
</div>

    </div> 
</div>
    	</div>
</section>








<div class="container">
	<div class="row">
		<div class="col-md-9 col-sm-12 hy-main-content">
		
			<div class="hy-layout clearfix"><div style="margin-top:0px"><?php echo get_ad(13)?></div>
				<div class="hy-switch-tabs">
					<ul class="nav nav-tabs">
						<li class="active"><a href="#list3" data-toggle="tab">正在播放-美女热舞-神曲-YY-在线播放</a></li>
											</ul>
				</div>
				<div class="tab-content">
					<div class="hy-play-list tab-pane fade in active" id="list3">
						<div class="item">
							<div class="plot">
								欢迎大家来到影视平台！美女热舞-神曲-YY-在线播放，如果播放有问题,请点击<a href='./book.php'style="color:#ff9900">☞留言☜</a>反馈给我们。好用请推荐给你的朋友！</div>
						</div>
					</div>
				</div>
			</div>
			
			<div class="hy-layout clearfix">
				<div class="hy-video-head">
					<h3 class="margin-0">影片评论</h3>
				</div>
				<div class="ff-forum" id="ff-forum" data-id="37432" data-sid="1">
<?php echo $mkcms_changyan; ?>
</div>
			</div>
		</div>
		<div class="col-md-3 col-sm-12 hy-main-side hidden-sm hidden-xs">
			<div class="hy-layout clearfix">
				<div class="hy-details-qrcode side clearfix">
					<div class="item">
						<h5 class="text-muted">扫一扫用手机观看</h5>
						<p>
						<img src="images/ew.png" width="250">
						</p>
						<p class="text-muted">
							分享到朋友圈
						</p>
					</div>
				</div>
				<div class="hy-video-ranking side clearfix">
					<div class="head">
						<a class="text-muted pull-right" href="./vlist.php">更多 <i class="icon iconfont icon-right"></i></a>
						<h4><i class="icon iconfont icon-top text-color"></i> 抢先看资源</h4>
					</div>
					<div class="item">
						<ul class="clearfix">
						<?php $result = mysql_query('select * from mkcms_vod order by d_id desc LIMIT 0,12');
		while ($row = mysql_fetch_array($result)){
$cc="./bplay.php?play=";
								$dd="../../bplay/";
if ($pucms_wei==1){
$ccb=$dd.$row['d_id'];
}
else{
$ccb=$cc.$row['d_id'];	
}
			echo '<li class="text-overflow"><span class="pull-right text-color">->></span><a href="'.$ccb.'" title="'.$row['d_name'].'">
						<em class="number active ">抢先</em>'.$row['d_name'].'</a></li>';
		}?>			

						</ul>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>
					
<span class="ff-hits" id="ff-hits-insert" data-id="37432" data-sid="vod" data-type="insert"></span>		<script>
	    var swiper = new Swiper('.hy-switch', {
	        pagination: '.swiper-pagination',
	        paginationClickable: true,
	        slidesPerView: 5,
	        spaceBetween: 0,
	        nextButton: '.swiper-button-next',
	        prevButton: '.swiper-button-prev',
	        breakpoints: {
	            1200: {
	                slidesPerView: 4,
	                spaceBetween: 0
	            },
	            767: {
	                slidesPerView: 3,
	                spaceBetween: 0					            
	            }
	        }
	    });	 
	    </script>
<span class="ff-record-set" data-sid="1" data-id="37432" data-id-sid="1" data-id-pid="1">
</span>

<?php include 'footer.php'; ?>
<script type="text/javascript ">
					$MH.limit = 10;
					$MH.WriteHistoryBox(200, 170, 'font');
					$MH.recordHistory({
						name: '<?php echo $timu; ?>',
						link: '<?php echo 'http://'.$_SERVER['HTTP_HOST'].$_SERVER['PHP_SELF'].'?'.$_SERVER['QUERY_STRING'];?>',
						pic: '/m-992/uploads/allimg/201706/a0a13289528feabb.jpg'
					})
				</script>


</body>
</html>
