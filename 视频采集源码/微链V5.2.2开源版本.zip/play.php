<?php include('system/inc.php');
include('system/playurl.php');
include('moban/'.$mkcms_bdyun.'/play.php');?>