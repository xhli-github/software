<?php
error_reporting(0);//屏蔽所有错误
$m = array("Beautyleg" => "b", "3AGirL" => "3a", "4K-STAR" => "4k", "RQ-STAR" => "rq", "经典写真" => "m", "Rosimm" => "rs", "Siyamm" => "sy", "Ru1mm" => "ru", "Showgirl" => "s", "Pantyhose" => "ny", "丽柜Ligui" => "lg", "细高跟" => "xi", "微拍福利" => "p", "学院派私拍" => "xy", "性感车模" => "c", "PANS写真" => "ps", "动感小站" => "q", "锦尚天舞" => "qw", "国产私拍" => "a", "国产私拍II" => "2a", "韩国饭拍" => "f", "韩国饭拍II" => "2f", "韩国饭拍III" => "3f", "韩国MV" => "k", "韩国女主播" => "zb", "街拍美女" => "j", "街拍美女II" => "2j", "街拍美女III" => "3j", "街拍美女IV" => "4j", "街拍美女V" => "5j", "爱丝AISS" => "as", "推女郎" => "tg", "瑜伽美女" => "yg", "秀人写真" => "xr", "Ru1mm-vip" => "rv", "Allure Girls" => "au", "中高艺" => "z", "芬妮玉足" => "fn", "Ugirls尤果" => "ug", "赤足者" => "cz", "BL时尚写真" => "b",);
$url = "http://k.syasn.com/" . $m["" . $_GET['m'] . ""] . "/" . $m["" . $_GET['m'] . ""] . $i . ".mp4";//视频接口
?>
