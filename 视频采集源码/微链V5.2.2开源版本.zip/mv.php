

<?php include('system/inc.php');
error_reporting(0);
include('moban/'.$mkcms_bdyun.'/mv.php');?>
<?php
error_reporting(0);
include "./inc/aik.config.php";
include "./inc/init.php";
?>