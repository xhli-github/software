<?php include('system/inc.php');
error_reporting(0);
include('moban/'.$mkcms_bdyun.'/gaoxiao.php');?>
